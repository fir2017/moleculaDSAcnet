using System;
using System.Collections.Generic;
using System.Text;

namespace AtomProject.Molecula
{
	public class Legatura
	{
		List < ElementChimic > ListaDeElementeChimice;
		string tipDeLegatura;
		string informatii;
	}
}
