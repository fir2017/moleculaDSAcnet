using System;
using System.Collections.Generic;
using System.Text;

namespace AtomProject.Molecula
{
	public class Molecula
	{
		string Denumire;
		List < Legatura > Legaturi;
		float MasaMoleculara;
		List < ElementChimic > ListaDeElementeChimice;
	}
}
