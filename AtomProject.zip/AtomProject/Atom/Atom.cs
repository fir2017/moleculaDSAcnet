using System;
using System.Collections.Generic;
using System.Text;

namespace AtomProject.Atom
{
	public class Atom
	{
		Nucleu nucleul;
		int invelisulElectronic;
		float MasaAtomica;
		int NumarAtomic;
	}
}
