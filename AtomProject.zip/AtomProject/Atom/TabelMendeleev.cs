using System;
using System.Collections.Generic;
using System.Text;

namespace AtomProject.Atom
{
	public class TabelMendeleev
	{
		List < ElementChimic > elementeChimice;
		List < perechePozitieElement> pozitiiElement;
		Table tabel;
	}
}
