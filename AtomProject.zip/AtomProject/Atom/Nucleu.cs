using System;
using System.Collections.Generic;
using System.Text;

namespace AtomProject.Atom
{
	public class Nucleu
	{
		List <Neutron> Neutroni;
		List <Proton> Protoni;
	}
}
