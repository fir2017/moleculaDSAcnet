using System;
using System.Collections.Generic;
using System.Text;

namespace AtomProject.Atom
{
	public class ElementChimic
	{
		Atom atom;
		string Tip;
	}
}
